import pyodbc
import mysql.connector as conector
from mysql.connector import *

#Datos para la conexión
server = '172.31.100.100'
database = 'adrs'
username = 'root'
password = 'Password@'
driver = '{MySQL ODBC 8.0 Unicode Driver}'


#Método para establecer la conexión
def conectarConBBDD():
    try:
        conexion = pyodbc.connect(f"DRIVER={driver};SERVER={server};DATABASE={database};UID={username};PWD={password}")
        return conexion
    except Error as e:
        print("No se ha podido realizar la conexión")
        return None

#Método para consultar 1 dato
def consultaDNI(conexion, ordenSQL):
    try:
        cursor = conexion.cursor()
        cursor.execute(ordenSQL)
        resultado = cursor.fetchone()   
        return resultado
    except Error as e:
        print("No se pudo realizar la consulta")

#Método para consultar varios datos
def consultaTicket(conexion, ordenSQL):
    try:
        cursor = conexion.cursor()
        cursor.execute(ordenSQL)
        conexion.commit()  # Confirmar los cambios en la base de datos
        return True
    except Error as e:
        conexion.rollback()  # Revertir los cambios en caso de error
        print("No se pudo realizar la consulta")