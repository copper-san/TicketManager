import Conexion
import hashlib

def iniciarSesion(dni, password):
    conexion = Conexion.conectarConBBDD()
    if conexion == None:
        print("No se ha conectado")
        return False
    else:
        try:
            resultado = Conexion.consultaDNI(conexion, "SELECT dni,contrasena FROM users WHERE dni="+"'" + dni + "'")
            if resultado:
                resSeparado = resultado.__str__().split(",")
                cifrado = hashlib.sha256()
                cifrado.update(password.encode('utf-8'))
                passwordCifrado = cifrado.hexdigest()
                passwordRecogido = resSeparado[1].lstrip().translate(str.maketrans("", "", "',()"))
                if passwordRecogido == passwordCifrado:
                    return True
                else:
                    return False
            else:
                print("No se encontro ningun resultado")
        except Conexion.Error as e:
            print("")

def cambiarPassword(dni, nueva_password):
    conexion = Conexion.conectarConBBDD()
    if conexion is None:
        print("No se ha podido conectar a la base de datos")
        return False
    else:
        try:
            cifrado = hashlib.sha256()
            cifrado.update(nueva_password.encode('utf-8'))
            nueva_password_cifrada = cifrado.hexdigest()

            # Actualizar la contraseña en la base de datos
            query = "UPDATE users SET contrasena = '{}' WHERE dni = '{}'".format(nueva_password_cifrada, dni)
            cursor = conexion.cursor()
            cursor.execute(query)
            
            # Verificar si la operación se realizó correctamente
            if cursor.rowcount > 0:
                conexion.commit()  # Confirmar los cambios en la base de datos
                print("Contraseña cambiada con éxito")
                return True
            else:
                conexion.rollback()  # Revertir los cambios en caso de error
                print("No se pudo cambiar la contraseña")
                return False
        except Conexion.Error as e:
            conexion.rollback()  # Revertir los cambios en caso de error
            print("Error al cambiar la contraseña:", str(e))
            return False
        
def sacarNombre(dni):
    conexion = Conexion.conectarConBBDD()
    if conexion == None:
        print("No se ha conectado")
        return False
    else:
        try:
            resultado = Conexion.consultaDNI(conexion, "SELECT nombre FROM users WHERE dni="+"'" + dni + "'")
            if resultado:
                resSeparado = resultado.__str__()
                nombreSeparado = resSeparado.translate(str.maketrans("", "", "',()"))
                nombreSeparado.upper()
                return nombreSeparado
            else:
                return False
        except Conexion.Error as e:
            print("")

def sacarApellido(dni):
    conexion = Conexion.conectarConBBDD()
    if conexion == None:
        print("No se ha conectado")
        return False
    else:
        try:
            resultado = Conexion.consultaDNI(conexion, "SELECT apellido FROM users WHERE dni="+"'" + dni + "'")
            if resultado:
                resSeparado = resultado.__str__()
                nombreSeparado = resSeparado.translate(str.maketrans("", "", "',()"))
                nombreSeparado.upper()
                return nombreSeparado
            else:
                return False
        except Conexion.Error as e:
            print("")          

def subirTicket(dni,fecha,asunto,mensaje):
    conexion = Conexion.conectarConBBDD()
    if conexion == None:
        print("No se ha conectado")
        return False
    else:
        try:
            resultado = Conexion.consultaDNI(conexion, "SELECT id FROM users WHERE dni="+"'" + dni + "'")
            if resultado:
                resultadoString = resultado.__str__()
                resultadoString = resultadoString.translate(str.maketrans("", "", ",()"))
                resultadoInsertar = Conexion.consultaTicket(conexion, "INSERT INTO tickets (id_usuario, fecha, asunto, mensaje) VALUES ('" + resultadoString + "', '" + fecha + "', '" + asunto + "', '" + mensaje + "');")
                if resultadoInsertar:
                    return True
                else:
                    return False
            else:
                return False
        except Conexion.Error as e:        
            print("")

def subirJornada(dni, fecha, hora_inicio, hora_fin, hora_comida, tiempo_pausa, tiempo_total):
    conexion = Conexion.conectarConBBDD()
    if conexion == None:
        print("No se ha conectado")
        return False
    else:
        try:
            resultado = Conexion.consultaDNI(conexion, "SELECT id FROM users WHERE dni="+"'" + dni + "'")
            if resultado:
                resultadoString = resultado.__str__()
                resultadoString = resultadoString.translate(str.maketrans("", "", ",()"))
                if hora_comida == None:
                    resultadoInsertar = Conexion.consultaTicket(conexion, "INSERT INTO horas (id_usuario, fecha, hora_inicio, hora_fin, hora_comida, tiempo_pausa, tiempo_total) VALUES ('{}', '{}', '{}', '{}', {}, {}, '{}');".format(resultadoString, fecha, hora_inicio, hora_fin, 'NULL', 'NULL', tiempo_total))
                else:
                    resultadoInsertar = Conexion.consultaTicket(conexion,"INSERT INTO  horas (id_usuario, fecha, hora_inicio, hora_fin, hora_comida, tiempo_pausa, tiempo_total) VALUES ('{}', '{}', '{}', '{}', '{}', '{}', '{}');".format(resultadoString, fecha, hora_inicio, hora_fin, hora_comida, tiempo_pausa, tiempo_total))
                if resultadoInsertar:
                    return True
                else:
                    return False
            else:
                return False
        except Conexion.Error as e:        
            print("")