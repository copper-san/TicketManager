import time
from PySide6.QtWidgets import *
from PySide6.QtGui import *
from PySide6.QtCore import *
from datetime import date
from datetime import datetime, timedelta
import threading
import Conector
import sys

#Clase para la ventana de login
class VentanaLogin(QMainWindow):
    def __init__(self):

        super().__init__()
        self.setGeometry(QRect(10,10,1000,800))

        #Widget principal
        self.widget = QWidget()
        self.widget.setGeometry(QRect(10, 10, 981, 781))
        self.widget.setObjectName("widget")

        #Ocultar los bordes de la ventana
        self.setWindowFlags(Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)

        #Panel de la izquierda
        self.panelizq = QLabel(parent=self.widget)
        self.panelizq.setGeometry(QRect(0, 0, 461, 781))
        self.panelizq.setStyleSheet("border-image: url(../RecursosGraficos/fondo.jpg);border-top-left-radius:50px;border-bottom-left-radius:50px;")
        self.panelizq.setObjectName("panelizq")

        #Panel de la derecha
        self.panelder = QLabel(parent=self.widget)
        self.panelder.setGeometry(QRect(460, 0, 521, 781))
        self.panelder.setStyleSheet("background-color: rgb(217, 217, 217);border-top-right-radius:50px;border-bottom-right-radius:50px;")
        self.panelder.setObjectName("panelder")

        #Barra para el usuario
        self.user = QLineEdit(parent=self.widget)
        self.user.setGeometry(QRect(500, 330, 441, 61))
        font = QFont()
        font.setPointSize(18)
        font.setBold(True)
        self.user.setFont(font)
        self.user.setStyleSheet("background-color:rgba(0,0,0,0);border:none;border-bottom: 2px solid rgba(46,82,101,200);color:rgba(0,0,0,240);padding-bottom:7px;")
        self.user.setObjectName("user")
        self.user.setPlaceholderText("DNI")

        #Barra para la contraseña
        self.password = QLineEdit(parent=self.widget)
        self.password.setGeometry(QRect(500, 440, 441, 71))
        font = QFont()
        font.setPointSize(18)
        font.setBold(True)
        self.password.setFont(font)
        self.password.setStyleSheet("background-color:rgba(0,0,0,0);border:none;border-bottom: 2px solid rgba(46,82,101,200);color:rgba(0,0,0,240);padding-bottom:7px;")
        self.password.setEchoMode(QLineEdit.EchoMode.Password)
        self.password.setObjectName("password")
        self.password.setPlaceholderText("Password")

        #Warning del Password
        self.passNone = QLabel(parent=self.widget)
        self.passNone.setGeometry(QRect(500, 520, 200, 21))
        font = QFont()
        font.setFamily("Arial")
        font.setPointSize(10)
        font.setBold(False)
        font.setItalic(False)
        self.passNone.setFont(font)
        self.passNone.setStyleSheet("background-color: rgb(0, 0, 0,0);font:75 10pt \"Arial\";color: rgb(255, 0, 0);border:None")
        self.passNone.setObjectName("passNone")

        #Sombra de la izquierda
        self.sombraizq = QLabel(parent=self.widget)
        self.sombraizq.setGeometry(QRect(0, 0, 461, 781))
        self.sombraizq.setStyleSheet("background-color:rgba(0,0,0,45);border-top-left-radius:50px;border-bottom-left-radius:50px;")
        self.sombraizq.setObjectName("sombraizq")

        #Botón de inicio
        self.inicio = QPushButton(parent=self.widget)
        self.inicio.setGeometry(QRect(500, 590, 441, 40))
        font = QFont()
        font.setPointSize(11)
        font.setBold(True)
        self.inicio.setFont(font)
        self.inicio.setObjectName("inicio")
        self.inicio.setText("I n i c i a r    S e s i ó n")
        self.inicio.setStyleSheet("QPushButton {background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop:1 rgba(85, 98, 112, 226));color:rgba(255,255,255,210);border-radius:5px;}"
                          "QPushButton:hover {background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85, 81, 84, 226));}"
                          "QPushButton:pressed {padding-left:5px;padding-top:5px;background-color:rgb(121, 66, 230);}")
        self.inicio.clicked.connect(self.iniciarSesion)
    
        #Texto de la izquierda
        self.textoizq = QLabel(parent=self.widget)
        self.textoizq.setGeometry(QRect(50, 180, 371, 111))
        font = QFont()
        font.setPointSize(31)
        font.setBold(True)
        self.textoizq.setFont(font)
        self.textoizq.setStyleSheet("color: rgb(255, 255, 255);")
        self.textoizq.setObjectName("textoizq")
        self.textoizq.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.textoizq.setText("R.R SOLV")

        #Sombra del texto
        self.sombratexto = QLabel(parent=self.widget)
        self.sombratexto.setGeometry(QRect(0, 180, 461, 321))
        self.sombratexto.setStyleSheet("background-color:rgba(0,0,0,40);")
        self.sombratexto.setObjectName("sombratexto")

        #Imagen de la izquierda
        self.imagenizq = QLabel(parent=self.widget)
        self.imagenizq.setGeometry(QRect(40, 270, 381, 201))
        self.imagenizq.setStyleSheet("image: url(../RecursosGraficos/logo.png);")
        self.imagenizq.setObjectName("imagenizq")

        #Label con la imgen de tipo usuario
        self.label = QLabel(parent=self.widget)
        self.label.setGeometry(QRect(590, 60, 241, 221))
        self.label.setStyleSheet("image: url(../RecursosGraficos/user.png);")
        self.label.setObjectName("label")

        #Warning del DNI
        self.DNI_NONE = QLabel(parent=self.widget)
        self.DNI_NONE.setGeometry(QRect(500, 400, 450, 21))
        font = QFont()
        font.setFamily("Arial")
        font.setPointSize(10)
        font.setBold(False)
        font.setItalic(False)
        self.DNI_NONE.setFont(font)
        self.DNI_NONE.setStyleSheet("background-color: rgb(0, 0, 0,0);font:75 10pt \"Arial\";color: rgb(255, 0, 0);border:None")
        self.DNI_NONE.setObjectName("DNI_NONE")

        #Botón para salir
        self.pushButton = QPushButton(parent=self.widget)
        self.pushButton.setGeometry(QRect(910, 10, 61, 61))
        self.pushButton.setStyleSheet("border-image: url(../RecursosGraficos/salir.png);")
        self.pushButton.setObjectName("pushButton")
        self.pushButton.clicked.connect(self.salir)
        self.pushButton.setCursor(QCursor(Qt.PointingHandCursor))

        #Asignar el widget a la ventana
        self.setCentralWidget(self.widget)
    
    #Metodo para inicar sesion
    def iniciarSesion(self):
        dni = self.user.text()
        password = self.password.text()

        if self.password.text() == "" and self.user.text() == "":
            self.passNone.setText("Debes ingresar la contraseña")
            self.DNI_NONE.setText("Debes ingresar un DNI")   
        elif self.user.text() == "":
            self.DNI_NONE.setText("Debes ingresar un DNI")
            self.passNone.setText("")
        elif self.password.text() == "":
            self.passNone.setText("Debes ingresar la contraseña")
            self.DNI_NONE.setText("")   
        else:
            resultado = Conector.iniciarSesion(dni,password)
            if resultado == None or resultado == False:
                self.DNI_NONE.setText("No existe ningun usuario relacionado o está mal ingresada la contraseña")
                self.passNone.setText("")
            else:
                self.DNI_NONE.setText("")
                self.passNone.setText("")
                self.w = VentanaMain(dni)
                self.w.show()
                self.hide()
    #Metodo para salir
    def salir(self):
        self.close()

#Clase para la ventana usuario
class VentanaMain(QMainWindow):
    def __init__(self,dni):

        print(dni)
        super().__init__()
        self.setGeometry(QRect(10,10,990,800))

        #Widget principal
        self.widget = QWidget()
        self.widget.setGeometry(QRect(10,10,971,781))
        self.widget.setObjectName("widget")

        #Ocultar los bordes de la ventana
        self.setWindowFlags(Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        
        #Menu izquierdo
        self.menu = QLabel(parent=self.widget)
        self.menu.setGeometry(QRect(0,0,301,781))
        self.menu.setStyleSheet("background-color:#000000;border-top-left-radius:50px;border-bottom-left-radius:50px;")
        self.menu.setText("")
        self.menu.setObjectName("Menu")

        #Widget vertical del menú izquierdo
        self.verticalLayoutWidget = QWidget(parent=self.widget)
        self.verticalLayoutWidget.setGeometry(QRect(0, 0, 301, 781))
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")

        #Layout vertical del menú izquierdo
        self.verticalLayout = QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")

        #Layout horizontal del menú izquierdo
        self.vertical = QVBoxLayout()
        self.vertical.setObjectName("horizontalLayout")

        #Elemento espaciador vacio
        self.separador = QFrame()
        self.separador.setFrameShape(QFrame.HLine)
        self.separador.setFixedHeight(150)
        self.separador.setStyleSheet("border:0px none")

        #Fuente
        font = QFont()
        font.setPointSize(1)
        font.setBold(True)

        #Elementos
        self.foto_user = QLabel(parent=self.verticalLayoutWidget)
        self.foto_user.setStyleSheet("image: url(../RecursosGraficos/USER_min.png);")
        self.foto_user.setObjectName("foto_user")

        self.textoizq = QLabel(parent=self.verticalLayoutWidget)
        self.textoizq.setFont(font)
        self.textoizq.setStyleSheet("font-size:31px;color:#ffffff;font-weight:900;background-color: rgba(255, 255, 255, 0);border-radius: 20px;margin:20px;padding:10px;")
        self.textoizq.setObjectName("textoizq")

        self.fichaje = QPushButton(parent=self.verticalLayoutWidget)
        self.fichaje.setFont(font)
        self.fichaje.setStyleSheet("QPushButton{font-size:25px;color:#ffffff;font-weight:600;background-color: rgba(255, 255, 255, 0);border-radius: 20px;margin:20px;padding:10px;}QPushButton:hover{font-size:25px;color:#ffffff;font-weight:600;background-color: rgba(255, 255, 255, 0.25);border-radius: 20px;margin:20px;padding:10px;}")
        self.fichaje.setObjectName("Fichaje")
        self.fichaje.setText("Fichaje")
        self.fichaje.setCursor(QCursor(Qt.PointingHandCursor))           

        self.tickets = QPushButton(parent=self.verticalLayoutWidget)
        self.tickets.setFont(font)
        self.tickets.setStyleSheet("QPushButton{font-size:25px;color:#ffffff;font-weight:600;background-color: rgba(255, 255, 255, 0);border-radius: 20px;margin:20px;padding:10px;}QPushButton:hover{font-size:25px;color:#ffffff;font-weight:600;background-color: rgba(255, 255, 255, 0.25);border-radius: 20px;margin:20px;padding:10px;}")
        self.tickets.setObjectName("Tickets")
        self.tickets.setText("Tickets")
        self.tickets.setCursor(QCursor(Qt.PointingHandCursor))        

        self.perfil = QPushButton(parent=self.verticalLayoutWidget)
        self.perfil.setFont(font)
        self.perfil.setStyleSheet("QPushButton{font-size:25px;color:#ffffff;font-weight:600;background-color: rgba(255, 255, 255, 0);border-radius: 20px;margin:20px;padding:10px;}QPushButton:hover{font-size:25px;color:#ffffff;font-weight:600;background-color: rgba(255, 255, 255, 0.25);border-radius: 20px;margin:20px;padding:10px;}")
        self.perfil.setObjectName("Perfil")
        self.perfil.setText("Perfil")
        self.perfil.setCursor(QCursor(Qt.PointingHandCursor))        

        #Añadir los elementos
        self.vertical.addWidget(self.separador)
        self.vertical.addWidget(self.foto_user)
        self.vertical.addWidget(self.textoizq)
        self.verticalLayout.addLayout(self.vertical)
        self.verticalLayout.addWidget(self.fichaje)
        self.verticalLayout.addWidget(self.tickets)
        self.verticalLayout.addWidget(self.perfil)

        #Widget Central
        self.principal = QLabel(parent=self.widget)
        self.principal.setGeometry(QRect(300, 0, 681, 781))
        self.principal.setStyleSheet("background-color:#E9E9E9;border-top-right-radius:50px;border-bottom-right-radius:50px;")
        self.principal.setObjectName("principal")

        #Label con la imgen del logo
        self.label_logo = QLabel(parent=self.widget)
        self.label_logo.setGeometry(QRect(525, 60, 241, 221))
        self.label_logo.setStyleSheet("image: url(../RecursosGraficos/logo.png);")
        self.label_logo.setObjectName("label_logo")

        #Poner el nombre
        nombre = Conector.sacarNombre(dni)

        #Texto de bienvenido
        self.labelBienvenido = QLabel(parent=self.widget)
        self.labelBienvenido.setGeometry(QRect(350, 250, 600, 221))
        self.labelBienvenido.setText("BIENVENDID@,\n" + nombre)
        self.labelBienvenido.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.labelBienvenido.setStyleSheet("font-size:31px;font-weight:900;color:black;")

        #Asignar el nombre al panel de la izquierda
        self.textoizq.setText(dni)
        self.textoizq.setAlignment(Qt.AlignmentFlag.AlignCenter)

        #Botón para salir
        self.pushButton = QPushButton(parent=self.widget)
        self.pushButton.setGeometry(QRect(910, 10, 61, 61))
        self.pushButton.setStyleSheet("border-image: url(../RecursosGraficos/salir.png);")
        self.pushButton.setObjectName("pushButton")
        self.pushButton.clicked.connect(self.salir)
        self.pushButton.setCursor(QCursor(Qt.PointingHandCursor))     

        #Conectar los botónes
        self.fichaje.clicked.connect(lambda: self.metodoFichaje())
        self.tickets.clicked.connect(lambda: self.metodoTickets(dni))   
        self.perfil.clicked.connect(lambda: self.metodoPerfil())   
        
        #Widget Principal
        self.setCentralWidget(self.widget)

        #Comprobación para el fichaje
        self.fichajeIniciado = False
    
    #Fichajes
    def metodoFichaje(self):

        #Ocultar los elementos
        self.ocultarElementos()

        #Activar los otros botones
        self.tickets.setEnabled(True)
        self.tickets.setStyleSheet("QPushButton{font-size:25px;color:#ffffff;font-weight:600;background-color: rgba(255, 255, 255, 0);border-radius: 20px;margin:20px;padding:10px;}QPushButton:hover{font-size:25px;color:#ffffff;font-weight:600;background-color: rgba(255, 255, 255, 0.25);border-radius: 20px;margin:20px;padding:10px;}")

        self.perfil.setEnabled(True)
        self.perfil.setStyleSheet("QPushButton{font-size:25px;color:#ffffff;font-weight:600;background-color: rgba(255, 255, 255, 0);border-radius: 20px;margin:20px;padding:10px;}QPushButton:hover{font-size:25px;color:#ffffff;font-weight:600;background-color: rgba(255, 255, 255, 0.25);border-radius: 20px;margin:20px;padding:10px;}")

        #Bloquear el botón actual
        self.fichaje.setStyleSheet("QPushButton{font-size:25px;color:#ffffff;font-weight:600;background-color: rgba(223, 223, 223, 0.35);border-radius: 20px;margin:20px;padding:10px;}QPushButton:hover{font-size:25px;color:#ffffff;font-weight:600;background-color: rgba(255, 255, 255, 0.25);border-radius: 20px;margin:20px;padding:10px;}")
        self.fichaje.setDisabled(True)

        if self.fichajeIniciado == True:
            self.btnIniciar.setText("Salir")
            self.principalFichaje.show()
        else:
            #Widget Central
            self.principalFichaje = QLabel(parent=self.widget)
            self.principalFichaje.setGeometry(QRect(300, 0, 681, 781))
            self.principalFichaje.setStyleSheet("background-color:#E9E9E9;border-top-right-radius:50px;border-bottom-right-radius:50px;")
            self.principalFichaje.setObjectName("principalFichaje")
            self.principalFichaje.show()

            #Hora actual
            self.lbl_txtHrActual = QLabel(parent=self.principalFichaje)
            self.lbl_txtHrActual.setGeometry(QRect(200, 160, 139, 51))
            self.lbl_txtHrActual.setStyleSheet("font-size:25px;font-weight:700;")
            self.lbl_txtHrActual.setText("Hora Actual")
            self.lbl_txtHrActual.setObjectName("lbl_txtHrActual")
            self.lbl_txtHrActual.show()

            self.lbl_hrActual = QLabel(parent=self.principalFichaje)
            self.lbl_hrActual.setGeometry(QRect(400, 170, 110, 31))
            self.lbl_hrActual.setMaximumSize(QSize(480, 16777215))
            self.lbl_hrActual.setStyleSheet("padding:5px;font-size:20px;font-weight:700;color:white;background-color:#7942e6;border-radius:10px;padding-left:10px;")
            self.lbl_hrActual.setObjectName("lbl_hrActual")
            self.lbl_hrActual.show()

            #Crear y ejecutar el hilo del temporizador
            temporizador_thread = threading.Thread(target=self.update_clock)
            temporizador_thread.start()

            #Inicio de jornada
            self.btnIniciar = QPushButton(parent=self.principalFichaje)
            self.btnIniciar.setGeometry(QRect(200, 690, 331, 35))
            self.btnIniciar.setStyleSheet("background-color:#7942e6;Color:white;font-size:20px;font-weight:700;border-radius:10px;padding:4px;padding-left:10px;padding-right:10px;")        
            self.btnIniciar.setText("Iniciar Jornada")
            self.btnIniciar.setCursor(QCursor(Qt.PointingHandCursor))     
            self.btnIniciar.clicked.connect(lambda: self.iniciarJornada(self.lbl_hrActual.text()))
            self.btnIniciar.show()

            #Botón para salir
            self.pushButtonFichaje = QPushButton(parent=self.principalFichaje)
            self.pushButtonFichaje.setGeometry(QRect(605, 10, 58, 58))
            self.pushButtonFichaje.setStyleSheet("border-image: url(../RecursosGraficos/salir.png);")
            self.pushButtonFichaje.setObjectName("pushButtonFichaje")
            self.pushButtonFichaje.clicked.connect(self.salir)
            self.pushButtonFichaje.setCursor(QCursor(Qt.PointingHandCursor))
            self.pushButtonFichaje.show()   

    def iniciarJornada(self,horaInicio):
        self.fichajeIniciado = True
        #Comprobación para salir de la jornada
        if self.btnIniciar.text() == "Salir":
            #Calculo para el total de la jornada
            hora_inicio = datetime.strptime(self.label_hrInicio.text(), "%H:%M:%S")
            hora_actual = datetime.strptime(self.lbl_hrActual.text(), "%H:%M:%S")
            tiempo_descanso = None
            #Poner la hora de descanso si ha habido
            try:
                hora_descanso = datetime.strptime(self.label_hrPausa.text(), "%H:%M:%S")
                tiempo_descanso = datetime.strptime(self.label_tiempoPausa.text(), "%H:%M:%S").time()
                tiempo_descanso = timedelta(hours=tiempo_descanso.hour, minutes=tiempo_descanso.minute, seconds=tiempo_descanso.second)
            except:
                pass
            horas_total = None
            if tiempo_descanso == None:
                horas_total = hora_actual - hora_inicio
            else:
                horas_total = (hora_actual - hora_inicio) - tiempo_descanso

            #Mensaje de aviso
            avisoSalida = QMessageBox()
            avisoSalida.setText("¿Estás seguro de que quieres irte?")
            avisoSalida.setInformativeText("Llevas " + str(horas_total) + " horas trabajadas")
            avisoSalida.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
            avisoSalida.setWindowFlags(Qt.FramelessWindowHint)
            avisoSalida.move(500,400)
            respuesta = avisoSalida.exec()

            #Procesar la respuesta del usuario
            if respuesta == QMessageBox.Yes:
                #Comprobar si la pausa sigue en ejecución
                if self.btn_pausa.text() == "Reanudar":
                    avisoPausa = QMessageBox()
                    avisoPausa.setText("Debes parar el tiempo de descanso, dale a 'Reanudar'")
                    avisoPausa.setStandardButtons(QMessageBox.Yes)
                    avisoPausa.setWindowFlags(Qt.FramelessWindowHint)
                    avisoPausa.move(500,400)
                    respuesta = avisoPausa.exec()   
                else:             
                    fecha_hoy = date.today().__str__()
                    hora_inicio = hora_inicio.strftime("%H:%M:%S")
                    hora_actual = hora_actual.strftime("%H:%M:%S")
                    if tiempo_descanso == None:
                        resultado = Conector.subirJornada(self.textoizq.text(),fecha_hoy,hora_inicio,hora_actual,None,None,horas_total)
                    else:
                        hora_descanso = hora_descanso.strftime("%H:%M:%S")
                        resultado = Conector.subirJornada(self.textoizq.text(),fecha_hoy,hora_inicio,hora_actual,hora_descanso,tiempo_descanso,horas_total)
                        self.btnIniciar.setEnabled(False)
            elif respuesta == QMessageBox.No:
                print("No")
        else:
            #Hora de inicio
            self.label_txtHrInicio = QLabel(parent=self.principalFichaje)
            self.label_txtHrInicio.setGeometry(QRect(200, 90, 131, 31))
            self.label_txtHrInicio.setStyleSheet("font-size:25px;font-weight:700;")
            self.label_txtHrInicio.setObjectName("label_txtHrInicio")
            self.label_txtHrInicio.setText("Hora inicio")
            self.label_txtHrInicio.show()

            self.label_hrInicio = QLabel(parent=self.principalFichaje)
            self.label_hrInicio.setGeometry(QRect(400, 90, 110, 31))
            self.label_hrInicio.setMaximumSize(QSize(480, 16777215))
            self.label_hrInicio.setStyleSheet("font-size:20px;font-weight:700;color:white;background-color:#7942e6;border-radius:10px;padding-left:10px;")
            self.label_hrInicio.setObjectName("label_hrInicio")
            self.label_hrInicio.setText(horaInicio)
            self.label_hrInicio.show()

            #Controlador del botón de pausa
            self.pausa_activa = False

            #Hora para la pausa
            self.horaPausa = None

            #Botón de pausa
            self.btn_pausa = QPushButton(parent=self.principalFichaje)
            self.btn_pausa.setGeometry(QRect(250, 560, 231, 35))
            self.btn_pausa.setStyleSheet("background-color:#7942e6;Color:white;font-size:20px;font-weight:700;border-radius:10px;padding:4px;padding-left:10px;padding-right:10px;")
            self.btn_pausa.setObjectName("btn_pausa")
            self.btn_pausa.setText("Pausa")
            self.btn_pausa.setCursor(QCursor(Qt.PointingHandCursor))  
            self.btn_pausa.clicked.connect(lambda: self.intercambiar_pausa())
            self.btn_pausa.show()

            #Crear el hilo para el conteo de la pausa
            self.semaforoThread = threading.Semaphore(1)
            self.temporizador_thread = threading.Thread(target=self.contadorPausa,args=(self.semaforoThread,))

            #Cambiar el boton de Inicio a Salir
            self.btnIniciar.setText("Salir")
            
    #Método para alternar entre pausa y reanudar
    def intercambiar_pausa(self):
        #Cambiar el estado
        if not self.pausa_activa:
            self.pausa_activa = True
        else:
             self.pausa_activa = False

        #Hora de inicio de la pausa
        self.label_txtHrPausa = QLabel(parent=self.principalFichaje)
        self.label_txtHrPausa.setGeometry(QRect(200, 310, 170, 51))
        self.label_txtHrPausa.setStyleSheet("font-size:25px;font-weight:700;")
        self.label_txtHrPausa.setObjectName("label_txtHrPausa")
        self.label_txtHrPausa.setText("Hora de pausa")
        self.label_txtHrPausa.show()

        self.label_hrPausa = QLabel(parent=self.principalFichaje)
        self.label_hrPausa.setGeometry(QRect(400, 320, 110, 31))
        self.label_hrPausa.setMaximumSize(QSize(480, 16777215))
        self.label_hrPausa.setStyleSheet("font-size:20px;font-weight:700;color:white;background-color:#7942e6;border-radius:10px;padding-left:10px;")
        self.label_hrPausa.setObjectName("label_hrPausa")
        self.label_hrPausa.show()

        if self.horaPausa is None and self.pausa_activa:
            #Definir la hora de pausa inicial
            self.horaPausa = datetime.now().strftime("%H:%M:%S")
        self.label_hrPausa.setText(self.horaPausa)

        #Actualizar el texto del botón
        if self.pausa_activa:
            self.btn_pausa.setText("Reanudar")
    
            #Tiempo de pausa
            self.label_txtTiempoPausa = QLabel(parent=self.principalFichaje)
            self.label_txtTiempoPausa.setGeometry(QRect(200, 400, 211, 51))
            self.label_txtTiempoPausa.setStyleSheet("font-size:25px;font-weight:700;")
            self.label_txtTiempoPausa.setObjectName("label_txtTiempoPausa")
            self.label_txtTiempoPausa.setText("Tiempo de pausa")
            self.label_txtTiempoPausa.show()

            self.label_tiempoPausa = QLabel(parent=self.principalFichaje)
            self.label_tiempoPausa.setGeometry(QRect(420, 410, 110, 31))
            self.label_tiempoPausa.setMaximumSize(QSize(480, 16777215))
            self.label_tiempoPausa.setStyleSheet("padding:5px;font-size:20px;font-weight:700;color:white;background-color:#7942e6;border-radius:10px;padding-left:10px;")
            self.label_tiempoPausa.setObjectName("label_tiempoPausa")
            self.label_tiempoPausa.show()
            
        #Iniciar el hilo si no está en ejecución
        if not self.temporizador_thread.is_alive():
            self.temporizador_thread.start()
                                   
    #Método para escribir el tiempo de pausa
    def actualizarTiempoPausaLabel(self, tiempo):
        QMetaObject.invokeMethod(self.label_tiempoPausa, "setText", Qt.QueuedConnection, Q_ARG(str, tiempo))

    #Método para llevar el tiempo de la pausa
    def contadorPausa(self,eventoThread):
        #Recoger la hora actual     
        horaPausa = datetime.now()
        while True:
            #Comprobar que no se haya presionado el botón de Reanudar
            if self.pausa_activa:
                #Reanudar el semaforo si está activa la pausa
                self.semaforoThread.release()
                #Calcular las diferencias para hh:mm:ss
                horaActual = datetime.now()
                tiempoTranscurrido = horaActual - horaPausa
                hours = tiempoTranscurrido.seconds // 3600
                minutes = (tiempoTranscurrido.seconds % 3600) // 60
                seconds = tiempoTranscurrido.seconds % 60
                tiempo_formateado = "{:02d}:{:02d}:{:02d}".format(hours, minutes, seconds)
                
                #Actualizar el tiempo de pausa en la ventana principal (debe usar signals para interactuar con la interfaz gráfica)
                self.actualizarTiempoPausaLabel(tiempo_formateado)
                self.btn_pausa.setText("Reanudar")
            else:
                self.semaforoThread.acquire()
                horaPausa = datetime.now() - tiempoTranscurrido
                self.btn_pausa.setText("Pausa")

            time.sleep(1)

    def update_clock(self):
        while True:
            #Obtener la hora actual
            hora_actual = datetime.now().strftime("%H:%M:%S")

            #Actualizar la etiqueta con la hora actual
            self.lbl_hrActual.setText(hora_actual)

            #Esperar 1 segundo antes de la próxima actualización
            time.sleep(1)

    #Tickets
    def metodoTickets(self,dni):
        #Método para ocultar los elementos de las interfaces
        self.ocultarElementos()

        #Activar los otros botones
        self.fichaje.setEnabled(True)
        self.fichaje.setStyleSheet("QPushButton{font-size:25px;color:#ffffff;font-weight:600;background-color: rgba(255, 255, 255, 0);border-radius: 20px;margin:20px;padding:10px;}QPushButton:hover{font-size:25px;color:#ffffff;font-weight:600;background-color: rgba(255, 255, 255, 0.25);border-radius: 20px;margin:20px;padding:10px;}")

        self.perfil.setEnabled(True)
        self.perfil.setStyleSheet("QPushButton{font-size:25px;color:#ffffff;font-weight:600;background-color: rgba(255, 255, 255, 0);border-radius: 20px;margin:20px;padding:10px;}QPushButton:hover{font-size:25px;color:#ffffff;font-weight:600;background-color: rgba(255, 255, 255, 0.25);border-radius: 20px;margin:20px;padding:10px;}")

        #Cambiar el botón de tickets
        self.tickets.setStyleSheet("QPushButton{font-size:25px;color:#ffffff;font-weight:600;background-color: rgba(223, 223, 223, 0.35);border-radius: 20px;margin:20px;padding:10px;}QPushButton:hover{font-size:25px;color:#ffffff;font-weight:600;background-color: rgba(255, 255, 255, 0.25);border-radius: 20px;margin:20px;padding:10px;}")
        self.tickets.setDisabled(True)

        #Ocultar los elementos de la ventana de bienvenida 
        self.label_logo.hide()
        self.labelBienvenido.hide()

        #Widget Central
        self.principalTickets = QLabel(parent=self.widget)
        self.principalTickets.setGeometry(QRect(300, 0, 681, 781))
        self.principalTickets.setStyleSheet("background-color:#E9E9E9;border-top-right-radius:50px;border-bottom-right-radius:50px;")
        self.principalTickets.setObjectName("principalTickets")
        self.principalTickets.show()

        #Recoger el dni
        self.txt_DNI = QLabel(parent=self.principalTickets)
        self.txt_DNI.setGeometry(QRect(300,50,250,34))
        self.txt_DNI.setStyleSheet("font-size:31px;font-weight:600;")
        self.txt_DNI.setObjectName("txt_DNI")
        self.txt_DNI.setText(dni)
        self.txt_DNI.show()

        self.lbl_dni = QLabel(parent=self.principalTickets)
        self.lbl_dni.setGeometry(QRect(10,50,200,34))
        self.lbl_dni.setStyleSheet("margin-left:5px;font-size:25px;font-weight:700;")
        self.lbl_dni.setObjectName("lbl_dni")
        self.lbl_dni.setText("Tu DNI:")
        self.lbl_dni.show()

        #Recoger la fecha
        self.lbl_fecha = QLabel(parent=self.principalTickets)
        self.lbl_fecha.setGeometry(QRect(10,150,250,34))
        self.lbl_fecha.setStyleSheet("margin-left:5px;font-size:25px;font-weight:700;")
        self.lbl_fecha.setObjectName("lbl_fecha")
        self.lbl_fecha.setText("La fecha de hoy:")
        self.lbl_fecha.show()

        self.txt_fecha = QLabel(parent=self.principalTickets)
        self.txt_fecha.setGeometry(QRect(300,150,250,34))
        self.txt_fecha.setStyleSheet("font-size:31px;font-weight:600;")
        self.txt_fecha.setObjectName("txt_fecha")
        self.txt_fecha.setText(date.today().__str__())
        self.txt_fecha.show()

        #Recoger el asunto
        self.lbl_asunto = QLabel(parent=self.principalTickets)
        self.lbl_asunto.setGeometry(QRect(10,280,150,34))
        self.lbl_asunto.setStyleSheet("margin-left:5px;font-size:25px;font-weight:700;")
        self.lbl_asunto.setObjectName("lbl_asunto")
        self.lbl_asunto.setText("Asunto:")
        self.lbl_asunto.show()

        self.txt_asunto = QLineEdit(parent=self.principalTickets)
        self.txt_asunto.setGeometry(QRect(10,330,665,30))
        self.txt_asunto.setStyleSheet("margin-left:5px;margin-right:5px;background-color:#ffffff;font-size:15px;font-weight:500;border-radius:5px;border:1px solid black;")
        self.txt_asunto.setObjectName("txt_asunto")
        self.txt_asunto.textChanged.connect(self.actualizarCharAsunto)
        self.txt_asunto.show()

        #Contador del asunto
        self.contadorAsunto = QLabel("0/75",parent=self.principalTickets)
        self.contadorAsunto.setGeometry(QRect(630,360,42,20))
        self.contadorAsunto.setStyleSheet("border:0px none;color:#000000;font-weight:700;border:1px solid black;background-color:#ffffff;border-radius:5px;")
        self.contadorAsunto.show()

        #Desabilitar las interacciones con el contador
        self.contadorAsunto.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.contadorAsunto.setMouseTracking(False)
        
        #Poner por encima del contador al txt_mensaje
        self.txt_asunto.raise_()

        #Label mensaje
        self.lbl_msg = QLabel(parent=self.principalTickets)
        self.lbl_msg.setGeometry(QRect(10,450,150,34))
        self.lbl_msg.setStyleSheet("margin-left:5px;font-size:25px;font-weight:700;")
        self.lbl_msg.setObjectName("lbl_msg")
        self.lbl_msg.setText("Mensaje:")
        self.lbl_msg.show()

        #Contador del mensaje
        self.contadorMensaje = QLabel("0/500",parent=self.principalTickets)
        self.contadorMensaje.setGeometry(QRect(620,700,53,19))
        self.contadorMensaje.setStyleSheet("border:0px none;color:#000000;font-weight:700;border:1px solid black;background-color:#ffffff;border-radius:5px;")
        self.contadorMensaje.show()

        #Contenedor del mensaje
        self.txt_mensaje = QTextEdit(parent=self.principalTickets)
        self.txt_mensaje.setGeometry(QRect(10,500,665,200))
        self.txt_mensaje.setStyleSheet("border:1px solid black;margin-left:5px;margin-right:5px;background-color:#ffffff;font-size:15px;font-weight:500; border-radius:15px;")
        self.txt_mensaje.setObjectName("txt_mensaje")
        self.txt_mensaje.textChanged.connect(self.actualizarCharMensaje)
        self.txt_mensaje.show()

        #Desabilitar las interacciones con el contador
        self.contadorMensaje.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.contadorMensaje.setMouseTracking(False)
        self.contadorMensaje.show()

        #Poner por encima del contador al txt_mensaje
        self.txt_mensaje.raise_()

        #Mensaje de error
        self.errorTicket = QLabel(parent=self.principalTickets)
        self.errorTicket.setGeometry(QRect(10,370,665,50))
        self.errorTicket.setStyleSheet("background-color: rgb(0, 0, 0,0);font:75 10pt \"Arial\";color: rgb(255, 0, 0);border:None;font-size:21px;font-weight:500;")
        self.errorTicket.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.errorTicket.show()

        #Botón de enviar
        self.btn_enviar = QPushButton(parent=self.principalTickets)
        self.btn_enviar.setGeometry(QRect(250,725,200,40))
        self.btn_enviar.setStyleSheet("background-color:#7942e6;font-size:25px;font-weight:800;color:#ffffff;border-radius:15px;")
        self.btn_enviar.setObjectName("btn_enviar")
        self.btn_enviar.setText("Enviar")
        self.btn_enviar.setCursor(QCursor(Qt.PointingHandCursor))     
        self.btn_enviar.clicked.connect(self.enviarTicket)
        self.btn_enviar.show()

        #Botón para salir
        self.pushButtonFichaje = QPushButton(parent=self.principalTickets)
        self.pushButtonFichaje.setGeometry(QRect(605, 10, 58, 58))
        self.pushButtonFichaje.setStyleSheet("border-image: url(../RecursosGraficos/salir.png);")
        self.pushButtonFichaje.setObjectName("pushButtonFichaje")
        self.pushButtonFichaje.clicked.connect(self.salir)
        self.pushButtonFichaje.setCursor(QCursor(Qt.PointingHandCursor))
        self.pushButtonFichaje.show()  

    #Método para actualizar los caracteres del mensaje
    def actualizarCharMensaje(self):
        text = self.txt_mensaje.toPlainText()
        char_count = len(text)
        self.contadorMensaje.setText(f"{char_count}/500")

        if char_count > 500:
            #Eliminar el ultimo caracter
            texto = self.txt_mensaje.toPlainText()
            self.txt_mensaje.setText(texto[:-1])

            #Dejar el cursor en el final
            new_cursor = self.txt_mensaje.textCursor()
            new_cursor.setPosition(500)
            self.txt_mensaje.setTextCursor(new_cursor)

            #Establecer el mensaje de error
            self.errorTicket.setText("Has llegado al máximo de caracteres")
            self.errorTicket.setStyleSheet("background-color: rgb(0, 0, 0,0);font:75 10pt \"Arial\";color: rgb(255, 0, 0);border:None;font-size:21px;font-weight:500;")
    
    #Método para actualizar los caracteres del asunto
    def actualizarCharAsunto(self):
        text = self.txt_asunto.text()
        char_count = len(text)
        self.contadorAsunto.setText(f"{char_count}/75")

        if char_count > 75:
            #Eliminar el ultimo caracter
            texto = self.txt_asunto.text()
            self.txt_asunto.setText(texto[:-1])

            #Dejar el cursor en el final
            self.txt_asunto.setCursorPosition(len(texto))

            #Establecer el mensaje de error
            self.errorTicket.setText("Has llegado al máximo de caracteres")
            self.errorTicket.setStyleSheet("background-color: rgb(0, 0, 0,0);font:75 10pt \"Arial\";color: rgb(255, 0, 0);border:None;font-size:21px;font-weight:500;")

    #Método para subir el ticket a la base de datos
    def enviarTicket(self):
        dni = self.txt_DNI.text()
        fecha = self.txt_fecha.text()
        asunto = self.txt_asunto.text()
        mensaje = self.txt_mensaje.toPlainText()
        resultado = Conector.subirTicket(dni,fecha,asunto,mensaje)
        if self.txt_asunto.text() == "" and self.txt_mensaje.toPlainText() == "" or self.txt_mensaje.toPlainText() == "" or self.txt_asunto.text() == "":
            self.errorTicket.setText("No puedes dejar un campo vacío")
            self.errorTicket.setStyleSheet("background-color: rgb(0, 0, 0,0);font:75 10pt \"Arial\";color: rgb(255, 0, 0);border:None;font-size:21px;font-weight:500;")
        else:           
            if resultado:
                self.txt_asunto.setText("")
                self.txt_mensaje.setText("")
                self.errorTicket.setText("Enviado correctamente")
                self.errorTicket.setStyleSheet("background-color: rgb(0, 0, 0,0);font:75 10pt \"Arial\";color: #38DF23;border:None;font-size:21px;font-weight:500;")
            else:
                self.errorTicket.setText("Ha ocurrido un error vuelve a intentarlo")

    #Perfil
    def metodoPerfil(self):
        #Activar los otros botones
        self.tickets.setEnabled(True)
        self.tickets.setStyleSheet("QPushButton{font-size:25px;color:#ffffff;font-weight:600;background-color: rgba(255, 255, 255, 0);border-radius: 20px;margin:20px;padding:10px;}QPushButton:hover{font-size:25px;color:#ffffff;font-weight:600;background-color: rgba(255, 255, 255, 0.25);border-radius: 20px;margin:20px;padding:10px;}")

        self.fichaje.setEnabled(True)
        self.fichaje.setStyleSheet("QPushButton{font-size:25px;color:#ffffff;font-weight:600;background-color: rgba(255, 255, 255, 0);border-radius: 20px;margin:20px;padding:10px;}QPushButton:hover{font-size:25px;color:#ffffff;font-weight:600;background-color: rgba(255, 255, 255, 0.25);border-radius: 20px;margin:20px;padding:10px;}")

        #Bloquear el botón actual
        self.perfil.setStyleSheet("QPushButton{font-size:25px;color:#ffffff;font-weight:600;background-color: rgba(223, 223, 223, 0.35);border-radius: 20px;margin:20px;padding:10px;}QPushButton:hover{font-size:25px;color:#ffffff;font-weight:600;background-color: rgba(255, 255, 255, 0.25);border-radius: 20px;margin:20px;padding:10px;}")
        self.perfil.setDisabled(True)

        #Widget Central
        self.principalPerfil = QLabel(parent=self.widget)
        self.principalPerfil.setGeometry(QRect(300, 0, 681, 781))
        self.principalPerfil.setStyleSheet("background-color:#E9E9E9;border-top-right-radius:50px;border-bottom-right-radius:50px;")
        self.principalPerfil.setObjectName("principalFichaje")
        self.principalPerfil.show()

        #Imagen de usuario
        self.imagenizqPerfil = QLabel(parent=self.principalPerfil)
        self.imagenizqPerfil.setGeometry(QRect(0, 150, 381, 201))
        self.imagenizqPerfil.setStyleSheet("image: url(../RecursosGraficos/user.png);")
        self.imagenizqPerfil.setObjectName("imagenizqPerfil")
        self.imagenizqPerfil.show()

        #Texto para el DNI
        self.lbl_dniPerfil = QLabel(parent=self.principalPerfil)
        self.lbl_dniPerfil.move(350, 130)
        self.lbl_dniPerfil.setStyleSheet("margin-top:50px;margin-left:5px;font-size:25px;font-weight:700;")
        self.lbl_dniPerfil.setObjectName("lbl_dniPerfil")
        self.lbl_dniPerfil.setText(self.textoizq.text())
        self.lbl_dniPerfil.show()

        #Coger el nombre y apellido
        nombre = Conector.sacarNombre(self.lbl_dniPerfil.text())
        apellido = Conector.sacarApellido(self.lbl_dniPerfil.text())

        #Texto para el nombre
        self.lbl_nombrePerfil = QLabel(parent=self.principalPerfil)
        self.lbl_nombrePerfil.move(350, 180)
        self.lbl_nombrePerfil.setStyleSheet("margin-top:50px;margin-left:5px;font-size:25px;font-weight:700;")
        self.lbl_nombrePerfil.setObjectName("lbl_nombrePerfil")
        self.lbl_nombrePerfil.setText(nombre)
        self.lbl_nombrePerfil.show()

        #Texto para el apellido
        self.lbl_apellidoPerfil = QLabel(parent=self.principalPerfil)
        self.lbl_apellidoPerfil.move(350, 220)
        self.lbl_apellidoPerfil.setStyleSheet("margin-top:50px;margin-left:5px;font-size:25px;font-weight:700;")
        self.lbl_apellidoPerfil.setObjectName("lbl_apellidoPerfil")
        self.lbl_apellidoPerfil.setText(apellido)
        self.lbl_apellidoPerfil.show()

        #Botón para cambiar contraseña
        self.btnCambiar = QPushButton(parent=self.principalPerfil)
        self.btnCambiar.move(200, 700)
        self.btnCambiar.setStyleSheet("padding:10px;background-color:#7942e6;font-size:24px;font-weight:700;color:#ffffff;border-radius:15px;")
        self.btnCambiar.setObjectName("btnCambiar")
        self.btnCambiar.setText("Cambiar Contraseña")
        self.btnCambiar.setCursor(QCursor(Qt.PointingHandCursor))     
        self.btnCambiar.clicked.connect(self.cambiarPassword)
        self.btnCambiar.show()

        #Botón para salir
        self.pushButtonPerfil = QPushButton(parent=self.principalPerfil)
        self.pushButtonPerfil.setGeometry(QRect(605, 10, 58, 58))
        self.pushButtonPerfil.setStyleSheet("border-image: url(../RecursosGraficos/salir.png);")
        self.pushButtonPerfil.setObjectName("pushButtonPerfil")
        self.pushButtonPerfil.clicked.connect(self.salir)
        self.pushButtonPerfil.setCursor(QCursor(Qt.PointingHandCursor))
        self.pushButtonPerfil.show()

        #Comprobación de que la contraseña esta correcta
        self.todoCorrecto = False

    #Método para cambiar la contraseña
    def cambiarPassword(self):
        if self.btnCambiar.text() == "Actualizar" and self.todoCorrecto == True:
            Conector.cambiarPassword(self.textoizq.text(),self.txtNuevoPassword1.text())
            self.btnCambiar.setText("Cambiar Contraseña")
            self.txtNuevoPassword1.hide()
            self.txtNuevoPassword2.hide()
        else:
            #Line edit para comprobar la actual
            self.txtPasswordActual = QLineEdit(parent=self.principalPerfil)
            self.txtPasswordActual.setGeometry(QRect(QRect(200, 460, 250, 30)))
            self.txtPasswordActual.setStyleSheet("background-color:#ffffff;font-size:15px;font-weight:500;border-radius:5px;border:1px solid black;")
            self.txtPasswordActual.setObjectName("txtPasswordActual")
            self.txtPasswordActual.setPlaceholderText("Contraseña actual")
            self.txtPasswordActual.setEchoMode(QLineEdit.EchoMode.Password)
            self.txtPasswordActual.show()

            #Texto de error del primer QLineEdit
            self.error1 = QLabel(parent=self.principalPerfil)
            self.error1.setGeometry(QRect(200, 490, 300, 21))
            font = QFont()
            font.setFamily("Arial")
            font.setPointSize(10)
            self.error1.setFont(font)
            self.error1.setStyleSheet("background-color: rgb(0, 0, 0,0);font:75 10pt \"Arial\";color: rgb(255, 0, 0);border:None")
            self.error1.setObjectName("error1")
            self.error1.show()

            #Botón para comprobar contraseña
            self.btnComprobar = QPushButton(parent=self.principalPerfil)
            self.btnComprobar.move(250, 520)
            self.btnComprobar.setStyleSheet("padding:10px;background-color:#7942e6;font-size:15px;font-weight:500;color:#ffffff;border-radius:15px;")
            self.btnComprobar.setObjectName("btnComprobar")
            self.btnComprobar.setText("Comprobar")
            self.btnComprobar.setCursor(QCursor(Qt.PointingHandCursor))     
            self.btnComprobar.clicked.connect(self.comprobarPassword)
            self.btnComprobar.show()

    def comprobarPassword(self):
        if self.txtPasswordActual.text() == "":
            self.error1.setText("No puede estar vacío")
        else:
            resultado = Conector.iniciarSesion(self.lbl_dniPerfil.text(),self.txtPasswordActual.text())
            if resultado == False:
                self.error1.setText("La contraseña introducida no es correcta")
            else:
                self.txtPasswordActual.hide()
                self.btnComprobar.hide()
                self.error1.setText("")
                self.error1.move(200,540)

                #Line edits para la contraseña nueva
                self.txtNuevoPassword1 = QLineEdit(parent=self.principalPerfil)
                self.txtNuevoPassword1.setGeometry(QRect(200, 460, 250, 30))
                self.txtNuevoPassword1.setStyleSheet("background-color:#ffffff;font-size:15px;font-weight:500;border-radius:5px;border:1px solid black;")
                self.txtNuevoPassword1.setObjectName("txtNuevoPassword1")
                self.txtNuevoPassword1.setPlaceholderText("Introduce la nueva contraseña")
                self.txtNuevoPassword1.setEchoMode(QLineEdit.EchoMode.Password)
                self.txtNuevoPassword1.textChanged.connect(self.comprobarNuevoPassword)
                self.txtNuevoPassword1.show()

                self.txtNuevoPassword2 = QLineEdit(parent=self.principalPerfil)
                self.txtNuevoPassword2.setGeometry(QRect(200, 500, 250, 30))
                self.txtNuevoPassword2.setStyleSheet("background-color:#ffffff;font-size:15px;font-weight:500;border-radius:5px;border:1px solid black;")
                self.txtNuevoPassword2.setObjectName("txtNuevoPassword2")
                self.txtNuevoPassword2.setPlaceholderText("Confirma la contraseña")
                self.txtNuevoPassword2.setEchoMode(QLineEdit.EchoMode.Password)
                self.txtNuevoPassword2.textChanged.connect(self.comprobarNuevoPassword)
                self.txtNuevoPassword2.show()

    def comprobarNuevoPassword(self):

        self.btnCambiar.setText("Actualizar")

        #Array para las condiciones de error
        condiciones = [False, False, False, False]  #[mayuscula, minuscula, numero, especial]

        for caracter in self.txtNuevoPassword1.text():
            if caracter.isalpha() and caracter.isupper():
                condiciones[0] = True
            elif caracter.isalpha() and caracter.islower():
                condiciones[1] = True
            elif caracter.isdigit():
                condiciones[2] = True
            elif not caracter.isalnum():
                condiciones[3] = True

        #Mostrar los mensajes de error correspondientes
        if not condiciones[0]:
            self.error1.setText("Debe contener al menos una mayúscula")
        elif not condiciones[1]:
            self.error1.setText("Debe contener al menos una minúscula")
        elif not condiciones[2]:
            self.error1.setText("Debe contener al menos un número")
        elif not condiciones[3]:
            self.error1.setText("Debe contener al menos un carácter especial")

        #Verificar si está vacío o si no son iguales
        elif self.txtNuevoPassword1.text() == "" or self.txtNuevoPassword2.text() == "":
            self.error1.setText("No puedes dejar ningún campo vacío")
        elif self.txtNuevoPassword1.text() != self.txtNuevoPassword2.text():
            self.error1.setText("Las contraseñas no coinciden")

        #Comprobar longitud mínima y máxima
        elif len(self.txtNuevoPassword1.text()) > 12:
            self.error1.setText("Máximo 12 caracteres")
        elif len(self.txtNuevoPassword1.text()) < 9:
            self.error1.setText("Mínimo 9 caracteres")
        else:
            self.error1.setText("")
            self.todoCorrecto = True

    def ocultarElementos(self):
        try:
            self.principalFichaje.hide()
            self.principalPerfil.hide()
            self.principalTickets.hide()
        except:
            pass

    def salir(self):
        self.close()

app = QApplication(sys.argv)
w = VentanaLogin()
w.show()
app.exec()